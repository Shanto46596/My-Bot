from pathlib import Path

ALLOWED_KEYS = {
    "BOT_NAME", "WELCOME_MESSAGE", "HELP_MESSAGE",
    "REPLY_PREFIX", "MAX_MESSAGE_LENGTH", "LOG_LEVEL"
}

DEFAULTS = {
    "BOT_NAME": "SHANTO BOT",
    "WELCOME_MESSAGE": "স্বাগতম! আমি আপনার ব্যক্তিগত Telegram Bot.",
    "HELP_MESSAGE": "কমান্ড: /start, /help, /id, /ping",
    "REPLY_PREFIX": "আপনার বার্তা পেয়েছি:",
    "MAX_MESSAGE_LENGTH": "3000",
    "LOG_LEVEL": "INFO",
}


def load_config(path="config.txt"):
    """Read simple KEY=VALUE text config. Never evaluates Python or shell code."""
    result = DEFAULTS.copy()
    file_path = Path(path)
    if not file_path.exists():
        return result

    for line_number, raw in enumerate(
        file_path.read_text(encoding="utf-8").splitlines(), start=1
    ):
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        if "=" not in line:
            raise ValueError(f"config.txt line {line_number}: expected KEY=VALUE")
        key, value = line.split("=", 1)
        key, value = key.strip(), value.strip()
        if key not in ALLOWED_KEYS:
            raise ValueError(f"config.txt line {line_number}: unsupported key {key!r}")
        result[key] = value

    try:
        limit = int(result["MAX_MESSAGE_LENGTH"])
    except ValueError as exc:
        raise ValueError("MAX_MESSAGE_LENGTH must be an integer") from exc
    if not 100 <= limit <= 3500:
        raise ValueError("MAX_MESSAGE_LENGTH must be between 100 and 3500")
    result["MAX_MESSAGE_LENGTH"] = limit

    level = result["LOG_LEVEL"].upper()
    if level not in {"DEBUG", "INFO", "WARNING", "ERROR"}:
        raise ValueError("LOG_LEVEL must be DEBUG, INFO, WARNING, or ERROR")
    result["LOG_LEVEL"] = level
    return result

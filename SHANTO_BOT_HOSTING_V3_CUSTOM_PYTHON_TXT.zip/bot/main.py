import logging
import os

from dotenv import load_dotenv
from telegram import Update
from telegram.ext import (
    Application, CommandHandler, ContextTypes,
    MessageHandler, filters,
)
from bot.config_loader import load_config

load_dotenv()

BOT_TOKEN = os.getenv("BOT_TOKEN", "").strip()
OWNER_ID_RAW = os.getenv("OWNER_ID", "").strip()
if not BOT_TOKEN:
    raise RuntimeError("BOT_TOKEN missing. Set it as a hosting secret.")
if not OWNER_ID_RAW.isdigit():
    raise RuntimeError("OWNER_ID must be your numeric Telegram user ID.")
OWNER_ID = int(OWNER_ID_RAW)

CONFIG = load_config(os.getenv("CONFIG_PATH", "config.txt"))
logging.basicConfig(
    level=CONFIG["LOG_LEVEL"],
    format="%(asctime)s %(levelname)s %(name)s: %(message)s",
)
log = logging.getLogger("shanto-custom-bot")


def allowed(update: Update) -> bool:
    return bool(update.effective_user and update.effective_user.id == OWNER_ID)


async def owner_guard(update: Update) -> bool:
    if not allowed(update):
        if update.effective_message:
            await update.effective_message.reply_text(
                "এই Bot-টি ব্যক্তিগত ব্যবহারের জন্য সীমাবদ্ধ।"
            )
        return False
    return True


async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await owner_guard(update):
        return
    await update.effective_message.reply_text(
        f"{CONFIG['WELCOME_MESSAGE']}\n\n/help লিখে কমান্ড দেখুন।"
    )


async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if await owner_guard(update):
        await update.effective_message.reply_text(CONFIG["HELP_MESSAGE"])


async def id_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await owner_guard(update):
        return
    await update.effective_message.reply_text(f"আপনার Telegram ID: {update.effective_user.id}")


async def ping_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if await owner_guard(update):
        await update.effective_message.reply_text("🟢 Bot is running.")


async def text_reply(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await owner_guard(update):
        return
    message = update.effective_message
    if not message or not message.text:
        return
    text = message.text.strip()
    if not text:
        return
    if len(text) > CONFIG["MAX_MESSAGE_LENGTH"]:
        await message.reply_text(
            f"বার্তাটি বড়। সর্বোচ্চ {CONFIG['MAX_MESSAGE_LENGTH']} অক্ষর পাঠান।"
        )
        return
    # This is a harmless example reply. Customize this function for your own bot.
    await message.reply_text(f"{CONFIG['REPLY_PREFIX']}\n\n{text}")


async def error_handler(update: object, context: ContextTypes.DEFAULT_TYPE):
    log.error("Telegram handler error", exc_info=context.error)


def main():
    app = Application.builder().token(BOT_TOKEN).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("help", help_command))
    app.add_handler(CommandHandler("id", id_command))
    app.add_handler(CommandHandler("ping", ping_command))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, text_reply))
    app.add_error_handler(error_handler)
    log.info("%s starting with long polling", CONFIG["BOT_NAME"])
    app.run_polling(drop_pending_updates=True)


if __name__ == "__main__":
    main()

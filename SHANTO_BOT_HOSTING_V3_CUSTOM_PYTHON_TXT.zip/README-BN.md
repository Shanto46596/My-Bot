# SHANTO BOT HOSTING V3 — Custom Python + TXT Config

এই প্রজেক্টটি নিজের তৈরি Telegram Bot-এর Python কোড (`bot/main.py`) এবং আলাদা plain-text configuration (`config.txt`) একসাথে চালানোর নিরাপদ starter template।

## গুরুত্বপূর্ণ পার্থক্য
- `main.py` হলো Bot-এর আসল Python logic।
- `config.txt` হলো শুধু `KEY=VALUE` সেটিংস। এটি Python code হিসেবে execute হয় না; `eval`, `exec` বা shell command চালানো হয় না।
- `BOT_TOKEN` ও `OWNER_ID` secret environment variables-এ থাকবে, `config.txt`-এ নয়।
- এই template ইচ্ছাকৃতভাবে arbitrary uploaded `.py` ফাইলকে web request থেকে execute করে না। নিজের কোড যাচাই করে project-এ বসিয়ে deploy করতে হবে।

## ১. Telegram Bot তৈরি
1. Telegram-এ `@BotFather` খুলে `/newbot` পাঠান।
2. নাম ও username দিন। BotFather token দেবে—এটি password-এর মতো গোপন রাখুন।
3. নিজের bot-এ `/start` ও `/id` চালিয়ে numeric Telegram user ID নিন।

## ২. ZIP-এ কী আছে
- `bot/main.py` — Telegram bot handlers; নিজের logic এখানে লিখবেন।
- `bot/config_loader.py` — নিরাপদ TXT settings reader; শুধু allowlisted key নেয়।
- `config.txt` — welcome/help/reply text এবং message length সেটিংস।
- `requirements.txt` — Python dependencies।
- `Dockerfile` — Python runtime image।
- `render.yaml` — persistent worker service definition।
- `.env.example` — local setup-এর নমুনা; আসল `.env` GitHub-এ দেবেন না।

## ৩. Local test (PC বা Termux)
1. ZIP Extract করুন।
2. Python 3.10+ ব্যবহার করুন।
3. project folder-এ `pip install -r requirements.txt` চালান।
4. `.env.example` কপি করে `.env` নাম দিন।
5. `.env`-এ `BOT_TOKEN` এবং `OWNER_ID` বসান।
6. চালান: `python -m bot.main`
7. Telegram-এ `/start`, `/help`, `/ping` এবং সাধারণ text পাঠিয়ে পরীক্ষা করুন।
8. বন্ধ করতে `Ctrl+C` দিন।

## ৪. নিজের Python Bot ও TXT সেটিংস কাস্টমাইজ
- Bot-এর কাজ বদলাতে `bot/main.py`-এর handler/function নিজের প্রয়োজন অনুযায়ী edit করুন।
- Reply/welcome/help text বদলাতে `config.txt` edit করুন।
- TXT format অবশ্যই `KEY=VALUE` হবে; ফাঁকা লাইন ও `#` comment চলবে।
- অনুমোদিত key: `BOT_NAME`, `WELCOME_MESSAGE`, `HELP_MESSAGE`, `REPLY_PREFIX`, `MAX_MESSAGE_LENGTH`, `LOG_LEVEL`।
- নতুন config key যোগ করতে `bot/config_loader.py`-এর `ALLOWED_KEYS` এবং defaults validation-এ যোগ করতে হবে।
- `config.txt`-এ token, password, API secret বা private credential রাখবেন না।

## ৫. ২৪/৭ Hosting (Render Worker)
1. GitHub-এ private repository তৈরি করুন।
2. ZIP-এর project files upload করুন। `.env` কখনো upload করবেন না।
3. Render-এ New → Blueprint নির্বাচন করে repository connect করুন।
4. Environment settings-এ `BOT_TOKEN` ও `OWNER_ID` secret হিসেবে যোগ করুন।
5. `render.yaml` অনুযায়ী worker deploy করুন।
6. Logs-এ `starting with long polling` দেখুন।
7. `config.txt` পরিবর্তন করলে repository-তে commit/push করে redeploy করুন।

এই config-এ `starter` worker plan দেওয়া আছে; এটি paid হতে পারে। Render-এর বর্তমান pricing ও plan availability deploy করার আগে যাচাই করুন। Free web hosting-এ ২৪/৭ worker guarantee ধরে নেবেন না।

## নিরাপত্তা
- Bot token কখনো public repository, screenshot বা chat-এ দেবেন না।
- Token ফাঁস হলে BotFather থেকে revoke/regenerate করে hosting secret update করুন।
- `OWNER_ID` ছাড়া অন্য account-কে bot ব্যবহার করতে দেওয়া হয় না।
- `config.txt` কেবল plain text setting; এটি code execution নয়।
- Arbitrary Python upload-and-run panel তৈরি করলে uploaded code server-এর নিয়ন্ত্রণ নিতে পারে। তাই এই starter-এ upload করা code স্বয়ংক্রিয়ভাবে execute হয় না।
- শুধু নিজের লেখা/বিশ্বস্ত code deploy করুন এবং dependencies যাচাই করুন।

## Netlify ও Firebase
Netlify static frontend host করতে পারে, কিন্তু Python bot process চালায় না। Firebase config/database রাখার কাজে লাগতে পারে, কিন্তু Python runtime worker-এর বিকল্প নয়। এই starter চালাতে Firebase বাধ্যতামূলক নয়।
